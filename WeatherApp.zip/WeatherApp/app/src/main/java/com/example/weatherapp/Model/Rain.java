package com.example.weatherapp.Model;

public class Rain {
}
